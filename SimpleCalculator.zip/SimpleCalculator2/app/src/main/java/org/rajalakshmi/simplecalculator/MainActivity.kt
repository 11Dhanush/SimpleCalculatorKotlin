package org.rajalakshmi.simplecalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvExpression: TextView = findViewById(R.id.textView4)
        val tvResult: TextView = findViewById(R.id.textView5)
        val bt0: Button = findViewById(R.id.BTN0)
        val bt1: Button = findViewById(R.id.BTN1)
        val bt2: Button = findViewById(R.id.BTN2)
        val bt3: Button = findViewById(R.id.BTN3)
        val bt4: Button = findViewById(R.id.BTN4)
        val bt5: Button = findViewById(R.id.BTN5)
        val bt6: Button = findViewById(R.id.BTN6)
        val bt7: Button = findViewById(R.id.BTN7)
        val bt8: Button = findViewById(R.id.BTN8)
        val bt9: Button = findViewById(R.id.BTN9)

        val btPlus: Button = findViewById(R.id.BTNADD)
        val btMinus: Button = findViewById(R.id.BTNMINUS)
        val btMul: Button = findViewById(R.id.BTNPER)
        val btDiv: Button = findViewById(R.id.BTNSLACH)

        val btEqual: Button = findViewById(R.id.BTNEQ)
        val btClear: Button = findViewById(R.id.BTNAC)


        var input1 : Double=0.0;
        var input2 : Double=0.0;
        var add:Boolean=false;
        var diff: Boolean=false;
        var mul:Boolean=false;
        var div:Boolean = false


//        btPlus.setOnClickListener() {
//
//        }


        bt0.setOnClickListener() {
            tvExpression.text = "${tvExpression.text}" + "0"
        }

        bt1.setOnClickListener() {
            tvExpression.text = "${tvExpression.text}" + "1"
        }

        bt2.setOnClickListener() {
            tvExpression.text = "${tvExpression.text}" + "2"
        }

        bt3.setOnClickListener() {
            tvExpression.text = "${tvExpression.text}" + "3"
        }

        bt4.setOnClickListener() {
            tvExpression.text = "${tvExpression.text}" + "4"
        }

        bt5.setOnClickListener() {
            tvExpression.text = "${tvExpression.text}" + "5"
        }

        bt6.setOnClickListener() {
            tvExpression.text = "${tvExpression.text}" + "6"
        }

        bt7.setOnClickListener() {
            tvExpression.text = "${tvExpression.text}" + "7"
        }

        bt8.setOnClickListener() {
            tvExpression.text = "${tvExpression.text}" + "8"
        }

        bt9.setOnClickListener() {
            tvExpression.text = "${tvExpression.text}" + "9"
        }
        btClear.setOnClickListener {
            tvExpression.setText(null)
            tvResult.setText(null)

        }

        btPlus.setOnClickListener {
            if (tvExpression.getText().length != 0) {
                input1 = "${tvExpression.text}".toDouble()
                add = true
                tvExpression.setText(null)
            }
        }
        btMinus.setOnClickListener {
            if (tvExpression.getText().length != 0) {
                input1 = "${tvExpression.text}".toDouble()
                diff = true
                tvExpression.setText(null)
            }
        }
        btMul.setOnClickListener {
            if (tvExpression.getText().length != 0) {
                input1 = "${tvExpression.text}".toDouble()
                mul = true
                tvExpression.setText(null)
            }
        }
        btDiv.setOnClickListener {
            if (tvExpression.getText().length != 0) {
                input1 = "${tvExpression.text}".toDouble()
                div = true
                tvExpression.setText(null)
            }
        }

        btEqual.setOnClickListener {
            input2 = "${tvExpression.text}".toDouble()
            if (add) {
                tvExpression.setText("${input1}+${input2}")
                var res = input1 + input2
                tvResult.setText("${res}")
                add = false
            }
            if (diff) {
                tvExpression.setText("${input1}-${input2}")
                var res = input1 - input2
                tvResult.setText("${res}")
                diff = false
            }
            if (mul) {
                tvExpression.setText("${input1}*${input2}")
                var res = input1 * input2
                tvResult.setText("${res}")
                mul = false
            }
            if (div) {
                tvExpression.setText("${input1}/${input2}")
                var res = input1 / input2
                tvResult.setText("${res}")
                div = false
            }

        }
    }

}